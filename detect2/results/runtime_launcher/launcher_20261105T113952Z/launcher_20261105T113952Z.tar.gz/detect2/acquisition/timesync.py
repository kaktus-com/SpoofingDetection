"""Optional Pi↔PX4 clock estimation. No GNSS synchronization is implied.

Exact request-token/source matching supports installed legacy TIMESYNC fields;
target extensions are checked when present. Offset = remote minus host.
"""
from collections import deque
import json
import queue
import statistics
import threading
import time


class TimeSyncTracker:
    def __init__(self, target=(1,1), identity=(245,191), max_rtt_ns=20_000_000,
                 jump_ns=100_000_000, expiry_ns=2_000_000_000):
        self.target,self.identity = target,identity
        self.max_rtt_ns,self.jump_ns,self.expiry_ns = max_rtt_ns,jump_ns,expiry_ns
        self.pending = {}; self.samples = deque(maxlen=31); self.segment = 0; self.last_token = 0
        self.expired=[]

    def request(self, now):
        self.expired=[t for t,s in self.pending.items() if now-s >= self.expiry_ns]
        self.pending = {t:s for t,s in self.pending.items() if now-s < self.expiry_ns}
        token = max(int(now),self.last_token+1); self.last_token = token
        self.pending[token] = int(now)
        return token

    def response(self, source, tc1, ts1, now, target=None):
        row={'host_monotonic_ns':int(now),'source_system':source[0],'source_component':source[1],
             'tc1_ns':int(tc1),'ts1_ns':int(ts1),'segment_id':self.segment,'accepted':False}
        if source != self.target: return {**row,'reason':'wrong_source'}
        if target and (target[0] not in (0,self.identity[0]) or target[1] not in (0,self.identity[1])):
            return {**row,'reason':'wrong_target'}
        if tc1 <= 0: return {**row,'reason':'remote_request_or_invalid_time'}
        if ts1 not in self.pending: return {**row,'reason':'unmatched_or_duplicate_token'}
        sent=self.pending.pop(ts1); rtt=int(now)-sent
        row['round_trip_ns']=rtt
        if rtt < 0 or rtt > self.max_rtt_ns: return {**row,'reason':'round_trip_rejected'}
        offset=int(tc1)-(sent+int(now))//2
        if self.samples and abs(offset-statistics.median(self.samples)) > self.jump_ns:
            self.segment += 1; self.samples.clear(); self.pending.clear()
            row['clock_discontinuity']=True
        self.samples.append(offset)
        return {**row,'accepted':True,'reason':'accepted','segment_id':self.segment,
                'remote_minus_host_ns':offset,'filtered_offset_ns':int(statistics.median(self.samples)),
                'half_round_trip_proxy_ns':rtt//2,'accepted_samples_in_segment':len(self.samples),
                'state':'warming_up' if len(self.samples)<5 else 'estimated_not_independently_verified'}


class TimeSyncObserver(threading.Thread):
    """Separate bounded decoder. Raw acquisition never waits on this observer."""
    def __init__(self, folder, sock, stop, issues, active=False, target=(1,1), identity=(245,191)):
        super().__init__(name='timesync-observer',daemon=True)
        self.folder,self.sock,self.stop,self.issues = folder,sock,stop,issues
        self.active,self.target,self.identity = active,target,identity
        self.queue = queue.Queue(64); self.finished = threading.Event()

    def observe(self, data, host_ns, peer):
        try: self.queue.put_nowait((data,host_ns,peer))
        except queue.Full: self.issues.add('timesync_observer_overflow')

    def run(self):
        try:
            from pymavlink.dialects.v20 import common as mav
            parsers={}; tracker=TimeSyncTracker(self.target,self.identity)
            encoder=mav.MAVLink(None,srcSystem=self.identity[0],srcComponent=self.identity[1])
            last_request=0; peer=None
            with (self.folder/'clock_sync.jsonl').open('w') as log, (self.folder/'mavlink_tx.bin').open('wb') as tx:
                def event(row):log.write(json.dumps(row)+'\n');log.flush()
                def send(message):
                    raw=message.pack(encoder);encoder.seq=(encoder.seq+1)%256
                    self.sock.sendto(raw,peer);tx.write(raw);tx.flush()
                while not self.finished.is_set() or not self.queue.empty():
                    try: data,now,origin=self.queue.get(timeout=.05)
                    except queue.Empty: data=None
                    if data is not None:
                        if origin not in parsers and len(parsers)>=8:
                            self.issues.add('timesync_peer_limit');self.queue.task_done();continue
                        parser=parsers.setdefault(origin,mav.MAVLink(None));parser.robust_parsing=True
                        try: messages=parser.parse_buffer(data) or []
                        except Exception as error:
                            event({'event':'decode_error','error':str(error)});messages=[]
                        for msg in messages:
                            source=(msg.get_srcSystem(),msg.get_srcComponent())
                            if source == self.target: peer=origin
                            if msg.get_type()!='TIMESYNC':continue
                            if msg.tc1==0:
                                event({'event':'remote_request','host_monotonic_ns':now,'source':source,'ts1_ns':msg.ts1})
                                if self.active and source==self.target and not self.stop.is_set():
                                    send(mav.MAVLink_timesync_message(time.monotonic_ns(),msg.ts1))
                            else:
                                target=(getattr(msg,'target_system',0),getattr(msg,'target_component',0))
                                event(tracker.response(source,msg.tc1,msg.ts1,now,target))
                        self.queue.task_done()
                    now=time.monotonic_ns()
                    if self.active and peer and not self.stop.is_set() and now-last_request>=100_000_000:
                        token=tracker.request(now)
                        for old in tracker.expired:event({'event':'request_expired','ts1_ns':old,'host_monotonic_ns':now})
                        send(mav.MAVLink_timesync_message(0,token))
                        event({'event':'request_sent','host_monotonic_ns':now,'ts1_ns':token});last_request=now
        except Exception as error:
            self.issues.add('timesync_observer_error',error=str(error))


